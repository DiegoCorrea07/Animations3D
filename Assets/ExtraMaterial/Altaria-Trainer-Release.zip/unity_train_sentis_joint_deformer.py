import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'  # Ignore verbose logging messages from TF

import tensorflow as tf

import math
import datetime
import time
import matplotlib.pyplot as plt

import tf2onnx
import onnx

import dataloader as dataloader
import models as models
import utils as utils

print(tf.version.VERSION)
print("Num GPUs Available: ", len(tf.config.list_physical_devices('GPU')))

# Training Parameters
CLUSTERS = 16  # 32
BATCH_SIZE = 1
EPOCHS = 60
BETAS = 0.1
SHUFFLE = True
MODEL_OUTPUT_NAME = "background_character"
INPUT_DATA_DIR = "./data_joint_deformer"


if __name__ == '__main__':

    # Tensorboard Callback
    dt_now = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    logdir = f"logs/_C{CLUSTERS}_E{EPOCHS}_B{BETAS}_Batch{BATCH_SIZE}_" + dt_now
    tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=logdir)

    # Early Stopping
    early_stopping = tf.keras.callbacks.EarlyStopping(
        monitor='val_loss',
        patience=10,
        restore_best_weights=True
    )

    # Checkpoint Callback
    checkpoint_filepath = './tmp/ckpt/checkpoint.model.keras'
    model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
        checkpoint_filepath,
        monitor='val_loss',
        mode='auto',
        save_best_only=True
    )

    # Load Data
    driver_quat_data, target_pos_data, target_quat_data = dataloader.load_binary_joint_data(INPUT_DATA_DIR)

    DECAY_STEPS = EPOCHS * int(math.floor(driver_quat_data[0].shape[0] / BATCH_SIZE))
    print(f"Decay steps: {DECAY_STEPS}")

    model = models.joint_deformation_model(
        x=driver_quat_data,
        y_pos=target_pos_data,
        y_quat=target_quat_data,
        centers=CLUSTERS,
        decay_steps=DECAY_STEPS,
        betas=BETAS
    )

    print(model.summary())

    training_time = time.time()
    history = model.fit(driver_quat_data, [target_pos_data, target_quat_data],
                        batch_size=BATCH_SIZE,
                        epochs=EPOCHS,
                        verbose=2,
                        shuffle=SHUFFLE,
                        validation_split=0.1,
                        callbacks=[
                            utils.LearningRateLoggingCallback(),
                            model_checkpoint_callback,
                            tensorboard_callback,
                        ])

    print("--- %s seconds ---" % (time.time() - training_time))
    last_loss = round(history.history['loss'][len(history.history['loss']) - 1], 6)

    model_name = f"{dt_now}_{MODEL_OUTPUT_NAME}_{BATCH_SIZE}_C{CLUSTERS}_B{BETAS}_{last_loss}.onnx"

    utils.save_onnx(export_name=model_name, trained_model=model, inputs=driver_quat_data)

    plt.plot(history.history['loss'], label="Loss")
    plt.plot(history.history['val_loss'], label="Val Loss")
    plt.show()
