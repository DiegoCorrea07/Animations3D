import glob
import numpy as np
import json
import struct
import os


def load_data(path, normalize_output=False, normalize_joints=False, debug=False):
    files = glob.glob(path + '/*.npz')

    delta_data = []
    joint_data = []
    quat_data = []
    for i in range(0, len(files)):
        data = np.load(files[i])
        delta_data.append(data["delta_data"])
        joint_data.append(data["joint_data"])
        quat_data.append(data["quat_data"])

    # Force float 32
    delta_data = np.float32(delta_data)
    joint_data = np.float32(joint_data)
    quat_data = np.float32(quat_data)

    delta_data = np.concatenate(delta_data)

    if normalize_output:
        print(f"Delta Min value: {delta_data.min()}")
        print(f"Delta Max value: {delta_data.max()}")
        delta_data = np.interp(delta_data, (delta_data.min(), delta_data.max()), (-1, +1))

    if normalize_joints:
        print(f"Joints Min value: {joint_data.min()}")
        print(f"Joints Max value: {joint_data.max()}")
        joint_data = np.interp(joint_data, (joint_data.min(), joint_data.max()), (-1, +1))

    print(f"Done loading {len(files)} poses...")
    return delta_data, joint_data, quat_data


def load_patch_data(path, debug=False):
    # Skinned
    with open(path + "/lod0_patch_info.json") as f:
        driver_patches = json.load(f)

    with open(path + "/lod1_patch_info.json") as f:
        deform_patches = json.load(f)

    return driver_patches, deform_patches


def divide_chunks(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]


def read_binary_file(path):
    f = open(path, 'rb')
    nums = int(os.path.getsize(path) / 4)
    data = struct.unpack('f' * nums, f.read(4 * nums))
    f.close()
    return data


def read_pos_binary_file(path):
    f = open(path, 'rb')
    nums = int(os.path.getsize(path) / 3)
    data = struct.unpack('f' * nums, f.read(3 * nums))
    f.close()
    return data


class FloatReader:
    def __init__(self, filename):
        self.f = open(filename, "rb")

    def read_floats(self, count: int):
        return np.fromfile(self.f, dtype=np.float32, count=count, sep='')


# ------------------------------------------------------------------------------------------------------
# Sentis Vertex Defomer
# ------------------------------------------------------------------------------------------------------

def load_binary_data(path, data_type=None):
    # Load info
    joint_count = 0
    vertex_count = 0
    with open(path + '/training_data_info.txt') as f:
        info_data = f.readlines()

        for l in info_data:
            l = l.strip()
            split = l.split(":")
            if split[0] == "JointCount":
                joint_count = int(split[1])
            elif split[0] == "VertexCount":
                vertex_count = int(split[1])

    if data_type == "x":
        print("Reading Joint Data")
        quat_files = glob.glob(path + '/x/*.bin')
        quat_files.sort()

        joint_data = []
        # Read Quaternion Data
        for i in range(0, len(quat_files)):
            data = read_binary_file(quat_files[i])

            x = list(divide_chunks(data, joint_count * 4))
            joint_data.append(x)

        joint_data = np.concatenate(joint_data)
        joint_data = np.float32(joint_data)
        split_size = int(joint_data.shape[1] / 4)
        joint_data_split = np.split(joint_data, split_size, axis=1)

        return joint_data_split, joint_data

    elif data_type == "y":
        print("Reading Delta Data")
        delta_data = []

        delta_files = glob.glob(path + '/y/*.bin')
        delta_files.sort()

        # Read Delta Data
        read_cnt = 0
        for i in range(0, len(delta_files)):
            print(f"Loading pose {delta_files[i]}")
            data = read_binary_file(delta_files[i])
            x = list(divide_chunks(data, vertex_count * 3))
            delta_data.append(x)
            read_cnt += 1

        delta_data = np.concatenate(delta_data)
        delta_data = np.float32(delta_data)

        delta_min = delta_data.min()
        delta_max = delta_data.max()
        print(f"Read {read_cnt} poses out of {len(delta_files)}")
        print(f"Delta Min value: {delta_min}")
        print(f"Delta Max value: {delta_max}")
        delta_data = np.interp(delta_data, (delta_data.min(), delta_data.max()), (-1, +1))
        meta_data = dict()
        meta_data["delta_min"] = delta_min
        meta_data["delta_max"] = delta_max

        return delta_data, meta_data


def load_unity_patch_data(path):
    files = glob.glob(path + '/*.txt')
    files.sort()

    patch_data = []
    for patch_file in files:
        with open(patch_file) as f:
            data = f.readlines()

        vtx_indexs = []
        for l in data:
            int_l = int(l.strip())
            vtx_indexs.append(int_l)

        patch_data.append(vtx_indexs)

    return patch_data


"""
Sentis Joint Deformer
"""


def load_binary_joint_data(path):
    driver_joint_count = 0
    target_joint_count = 0

    # Load Joint Count info
    with open(path + '/training_data_info.txt') as f:
        info_data = f.readlines()

        for l in info_data:
            l = l.strip()
            split = l.split(":")
            if split[0] == "DriverJointCount":
                driver_joint_count = int(split[1])
            elif split[0] == "TargetJointCount":
                target_joint_count = int(split[1])

    # Load Driver Quat Data
    data = read_binary_file(path + '/drivers_unity.bin')
    driver_quat_data = list(divide_chunks(data, driver_joint_count * 4))

    driver_quat_data = np.float32(driver_quat_data)
    split_size = int(driver_quat_data.shape[1] / 4)
    driver_quat_data = np.split(driver_quat_data, split_size, axis=1)

    # Load Target Pos Data
    data = read_binary_file(path + '/targets_pos_unity.bin')
    target_pos_data = list(divide_chunks(data, target_joint_count * 3))

    target_pos_data = np.float32(target_pos_data)

    # Load Target Quat Data
    data = read_binary_file(path + '/targets_quat_unity.bin')
    target_quat_data = list(divide_chunks(data, target_joint_count * 4))

    target_quat_data = np.float32(target_quat_data)

    return driver_quat_data, target_pos_data, target_quat_data
