import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'

import numpy as np
import tensorflow as tf
import tf2onnx
import onnx


def create_deform_patches_unity(data, patch_data, exclude_first_patch=False):
    return_data = []

    for i in range(0, len(patch_data)):
        # Exclude the first patch as that's "black"
        if exclude_first_patch and i == 0:
            continue

        new_patch = []

        for vtx in patch_data[i]:
            new_patch.append(data[:, (vtx*3)])
            new_patch.append(data[:, (vtx*3)+1])
            new_patch.append(data[:, (vtx*3)+2])

        return_data.append(np.stack(new_patch, axis=1))

    return return_data


def pad_zeros(nr):
    if nr < 10:
        return "000" + str(nr)
    elif 9 < nr < 100:
        return "00" + str(nr)
    elif nr > 999 :
        return "0" + str(nr)

    else:
        return str(nr)


class LearningRateLoggingCallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        lr = self.model.optimizer.learning_rate
        print("\n")
        print(lr.numpy())


def save_onnx(export_name, trained_model, inputs):
    """
    Save the model as ONNX
    :param export_name: name of the model
    :param trained_model: input model
    :param inputs: specify the models inputs
    :return: nothing
    """
    save_path = './trained_models/' + export_name
    input_signatures = []
    for i in range(0, len(inputs)):
        input_signatures.append(tf.TensorSpec((None, inputs[i].shape[1]), tf.float32, name=f'input_{i}'))
    onnx_model, _ = tf2onnx.convert.from_keras(trained_model, input_signatures, opset=13)
    onnx.save(onnx_model, save_path)
    print(f"ONNX Model Saved: {save_path}")