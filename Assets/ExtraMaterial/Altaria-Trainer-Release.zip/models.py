import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'
import tensorflow as tf

from rbf.rbflayer import RBFLayer, InitCentersKMeans
import utils as utils


# -----------------------------------------------------------------------------------
# SENTIS VERTEX DEFORMER
# -----------------------------------------------------------------------------------

def vertex_deformation_model(
        X,
        y,
        centers=5,
        decay_steps=1000,
        betas=1.0):

    inputs = []
    outputs = []
    rbf_layers = []

    for i in range(0, len(X)):
        source_input = tf.keras.layers.Input(shape=(X[i].shape[1],), name=f"input_{utils.pad_zeros(i)}")
        inputs.append(source_input)

        # noinspection PyCallingNonCallable
        rbf = RBFLayer(centers,  # len(centers), # 20
                                  initializer=InitCentersKMeans(X[i]),  # InitCentersKMeans(X[i]),
                                  betas=betas,  # betas,  # 2.0 # Radius
                                  input_shape=(X[i].shape[1],),
                                  name=f"rbf_{i}",
                                  )(source_input)

        rbf_layers.append(rbf)

    concatenated_output = tf.keras.layers.Concatenate()(rbf_layers)

    norm1 = tf.keras.layers.LayerNormalization()(concatenated_output)

    dense1 = tf.keras.layers.Dense(len(X) * centers,
                                   activation='relu',
                                   name=f"dense1_{i}")(norm1)
    drop1 = tf.keras.layers.Dropout(0.05, name=f"drop1_{i}")(dense1)

    #256
    dense2 = tf.keras.layers.Dense(128,
                                   activation='relu',
                                   name=f"dense2_{i}")(drop1)
    drop2 = tf.keras.layers.Dropout(0.05, name=f"drop2_{i}")(dense2)

    #128
    dense3 = tf.keras.layers.Dense(64,
                                   activation='relu',
                                   name=f"dense3_{i}")(drop2)
    drop3 = tf.keras.layers.Dropout(0.05, name=f"drop3_{i}")(dense3)

    for i in range(0, len(y)):
        # attention = tf.keras.layers.Attention()([in1, in2])
        #128
        dense4 = tf.keras.layers.Dense(64,
                                       activation='relu',
                                       name=f"dense4_{i}")(drop3)

        drop4 = tf.keras.layers.Dropout(0.05, name=f"drop4_{i}")(dense4)

        #128 #32
        dense5 = tf.keras.layers.Dense(32,
                                       activation='relu',
                                       name=f"dense5_{i}")(drop4)

        y1_output = tf.keras.layers.Dense(y[i].shape[1],
                                              activation='linear',
                                              use_bias=False,
                                              name=f'output_{utils.pad_zeros(i)}')(dense5)

        outputs.append(y1_output)

    model = tf.keras.models.Model(inputs=inputs, outputs=outputs)

    loss_ = tf.keras.losses.MeanSquaredError(
        reduction='sum_over_batch_size',
        name='mean_squared_error'
    )

    initial_learning_rate = 0.0001
    lr_decayed_fn = tf.keras.optimizers.schedules.CosineDecay(initial_learning_rate, decay_steps=decay_steps, alpha=0.000001)
    optimizer = tf.keras.optimizers.Adam(learning_rate=lr_decayed_fn)

    model.compile(loss=loss_, optimizer=optimizer)

    return model

# -----------------------------------------------------------------------------------
# SENTIS JOINT DEFORMER
# -----------------------------------------------------------------------------------


def joint_deformation_model(
        x=None,
        y_pos=None,
        y_quat=None,
        centers=5,
        betas=1.0,
        decay_steps=1000):

    inputs = []
    rbf_layers = []

    for i in range(0, len(x)):
        source_input = tf.keras.layers.Input(shape=(x[i].shape[1],), name=f"input_{utils.pad_zeros(i)}")
        inputs.append(source_input)

        # noinspection PyCallingNonCallable
        rbf = RBFLayer(centers,  # len(centers), # 20
                                  initializer=InitCentersKMeans(x[i]),  # InitCentersKMeans(X[i]),
                                  betas=betas, # Radius
                                  input_shape=(x[i].shape[1],),
                                  name=f"rbf_{i}",
                                  )(source_input)

        rbf_layers.append(rbf)

    concatenated_output = tf.keras.layers.Concatenate()(rbf_layers)

    norm1 = tf.keras.layers.LayerNormalization()(concatenated_output)

    dense1 = tf.keras.layers.Dense(len(x) * centers, activation='relu', name=f"dense1_{i}")(norm1)

    # Branch layer for quaternion
    pos_layer = tf.keras.layers.Dense(64, activation='relu', name='pos_layer')(dense1)
    pos_layer2 = tf.keras.layers.Dense(32, activation='relu', name='pos_layer_2')(pos_layer)

    # Position Output Layer
    y1_output = tf.keras.layers.Dense(y_pos.shape[1], activation=None, name='position_output')(pos_layer2)

    # Branch layer for quaternion
    quat_layer = tf.keras.layers.Dense(64, activation='relu', name='quat_layer')(dense1)
    quat_layer2 = tf.keras.layers.Dense(32, activation='relu', name='quat_layer_2')(quat_layer)

    # Quaternion output layer
    y2_output = tf.keras.layers.Dense(y_quat.shape[1], activation=None, name='quaternion_output')(quat_layer2)

    model = tf.keras.models.Model(inputs=inputs, outputs=[y1_output, y2_output])

    # Cosine Decay
    initial_learning_rate = 0.001
    lr_decayed_fn = tf.keras.optimizers.schedules.CosineDecay(initial_learning_rate, decay_steps=decay_steps,
                                                              alpha=0.000001)
    optimizer = tf.keras.optimizers.Adam(learning_rate=lr_decayed_fn)

    # Loss
    loss_ = tf.keras.losses.MeanSquaredError(
        reduction='sum_over_batch_size',
        name='mean_squared_error'
    )

    model.compile(loss=loss_, optimizer=optimizer)

    return model