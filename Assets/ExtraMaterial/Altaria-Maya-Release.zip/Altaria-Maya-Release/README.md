# Altaria Maya Training Tool



## Starting the tool in Maya:
````python
import sys
if "{YOUR_PATH}/Altaria-Maya-Release/python" not in sys.path:
    sys.path.append("{YOUR_PATH}/Altaria-Maya-Release/python")

import importlib
import altaria as alt_c
importlib.reload(alt_c)
alt_c.show_ui()
````