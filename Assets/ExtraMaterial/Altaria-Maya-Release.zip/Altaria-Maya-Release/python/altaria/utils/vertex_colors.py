import os
import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya
import math
import numpy as np

def round_color(col):
    r = round(col.r, 3)
    g = round(col.g, 3)
    b = round(col.b, 3)
    return [r,g,b]

def list_vertex_colors(selected_object, deform_patch=False):
    dag = OpenMaya.MGlobal.getActiveSelectionList().add(selected_object).getDagPath(0)

    patches_colors = []
    patches_indexes = []

    full_color_vertex_set = dict()
    connected_vertex_set = dict()

    # Get nr of colors
    vert_itr = OpenMaya.MItMeshVertex(dag)
    while not vert_itr.isDone():
        col = round_color(vert_itr.getColor())
        if col not in patches_colors:
            patches_colors.append(col)
        vert_itr.next()
    for i in range(0, len(patches_colors)):
        patches_indexes.append([])

    # Sort according to patch
    vert_itr = OpenMaya.MItMeshVertex(dag)
    while not vert_itr.isDone():
        index = vert_itr.index()

        col = round_color(vert_itr.getColor())
        col_index = patches_colors.index(col)
        patches_indexes[col_index].append(index)

        # For finding adjacent vertices
        full_color_vertex_set[index] = col
        connected_vertices = vert_itr.getConnectedVertices()
        connected_vertex_set[index] = connected_vertices

        vert_itr.next()

    if not deform_patch:
        for patch in range(0, len(patches_indexes)):
            append_set = []
            for i in range(0, len(patches_indexes[patch])):
                vertex_index = patches_indexes[patch][i]

                col = full_color_vertex_set[vertex_index]
                for k in connected_vertex_set[vertex_index]:
                    if full_color_vertex_set[k] != col:
                        append_set.append(k)

            patches_indexes[patch] += append_set

    return patches_colors, patches_indexes