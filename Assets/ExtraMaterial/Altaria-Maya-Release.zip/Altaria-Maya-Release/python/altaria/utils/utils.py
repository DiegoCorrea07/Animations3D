import inspect
from maya import cmds
import maya.mel as mel

def pad_zeros(nr):
    if nr < 10:
        return "000" + str(nr)
    elif 9 < nr < 100:
        return "00" + str(nr)
    elif nr > 999 :
        return "0" + str(nr)

    else:
        return str(nr)


def round_color(col):
    r = round(col.r, 2)
    g = round(col.g, 2)
    b = round(col.b, 2)
    return [r, g, b]

def reset_bake_options():
    mel.eval('optionVar -floatValue bakeSimulationByTime 1.0')
    mel.eval('optionVar -intValue bakeSimulationOversamplingRate 1')
    mel.eval('optionVar -intValue bakeSimulationImpCon 1')
    mel.eval('optionVar -intValue bakeSimulationPreserveKeys 1')
    mel.eval('optionVar -intValue bakeSimulationSparseAnimCurve 0')
    mel.eval('optionVar -intValue bakeSimulationRemoveBakedAttributeFromLayer 0')
    mel.eval('optionVar -intValue bakeSimulationBakeOnOverrideLayer 0')
    mel.eval('optionVar -intValue bakeSimulationSmartBake 0')
    mel.eval('optionVar -intValue bakeSimulationSmartFidelity 0.0')
    mel.eval('optionVar -floatValue bakeSimulationSmartFidelityDelta 5')
    mel.eval('optionVar -intValue minimizeRotation 1')

def show_viewport_message(text, back_color="grey", visible_length=5000, fade=True, echo_in_script_editor=False):
    if echo_in_script_editor is True:
        frame = inspect.stack()[1]
        module_name = inspect.getmodule(frame[0]).__name__

        print("%s -> inviewMessage: %s" % (module_name, text))
    try:
        if back_color.lower() == "red":
            back_color = 0x00FF0000
        elif back_color.lower() == "grey" or back_color.lower() == "gray":
            back_color = 0x00585858
        elif back_color.lower() == "green":
            back_color = 0x0021610B
    except:
        pass

    cmds.inViewMessage(assistMessage=text, backColor=back_color, fadeStayTime=visible_length, f=fade,
                       position="topCenter")

def strip_namespace(node):
    spaces = node.split(':')
    node_name = spaces[len(spaces) - 1]
    return node_name