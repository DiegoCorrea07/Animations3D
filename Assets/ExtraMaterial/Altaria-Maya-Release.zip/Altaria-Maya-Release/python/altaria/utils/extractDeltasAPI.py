# ----------------------------------------------------------------------------------------------
#
# extractDeltas.py
# v1.4
#
# extract a modeled corrective shape from a deformed skinned mesh
#
# original c++ extract deltas plugin by James Jacobs
#
# python conversion, improvements and maintenance by Ingo Clemens
# www.braverabbit.com
#
# brave rabbit, Ingo Clemens 2014
#
# versions:
#
# 1.4 - included mel scripts
# 1.3 - improved shape comparison without the need of blendshapes
# 1.2 - added the vertex list flag to work only on a given component list
# 1.1 - optimized performance because it now works on sculpted points only
#		(0.06 - c++ version, 1.88 - version 1.0, 0.14 - version 1.1)
# 1.0 - initial python conversion
#
# ----------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# ----------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------
#
#	USE AND MODIFY AT YOUR OWN RISK!!
#   https://github.com/italic-r/maya-prefs/blob/master/scripts/rigging/extractDeltas.py
#
# ----------------------------------------------------------------------------------------------

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya
import time

def extractDeltas(skinned=None, simulated=None):
    print("Extract Deltas")
    cmds.select([skinned, simulated], r=True)
    print(skinned, simulated)

    skinName = ''
    correctiveName = ''
    resultName = ''
    listString = ''

    sel = []
    if skinName != '' and correctiveName != '':
        sel.append(skinName)
        sel.append(correctiveName)
    else:
        sel = cmds.ls(sl=True, tr=True)

    shapeList = []
    for i in range(len(sel)):
        shapes = cmds.listRelatives(sel[i], s=True)
        if shapes == None:
            OpenMaya.MGlobal.displayError(sel[i] + ' has no shape node.')
            raise Exception
        if cmds.nodeType(shapes[0]) != 'mesh':
            OpenMaya.MGlobal.displayError(shapes[0] + ' is not a mesh object.')
            raise Exception
        elif i == 0 and len(shapes) > 1:
            skin = cmds.listConnections(shapes[0], type='skinCluster')
            if skin == None:
                OpenMaya.MGlobal.displayError(shapes[0] + ' is not bound to a skin cluster.')
                raise Exception
            if cmds.getAttr(shapes[1] + '.intermediateObject'):
                shapeList.append(shapes[1])
            else:
                OpenMaya.MGlobal.displayError(shapes[1] + ' is not an intermediate/original shape node.')
                raise Exception
        shapeList.append(shapes[0])

    # print(shapeList)
    if len(shapeList) != 3:
        OpenMaya.MGlobal.displayError(
            'Select a skinned mesh with a valid original shape node and a target mesh object.')
        raise Exception

    selList = OpenMaya.MSelectionList()
    for sl in shapeList:
        selList.add(sl)

    selList.add("deformedShape")

    # print(selList)
    # ('SkinnedShapeOrig', 'SkinnedShape', 'pack1', 'deformedShape')
    intermediateObj = OpenMaya.MObject()  # BindPose
    skinObj = OpenMaya.MObject()  # Skinned
    targetObj = OpenMaya.MObject()  # Cloth
    deformedObj = OpenMaya.MObject()  # output/deformed

    intermediateObj = selList.getDependNode(0)
    skinObj = selList.getDependNode(1)
    targetObj = selList.getDependNode(2)

    deformedObj = selList.getDependNode(3)

    # --------------------------------------------------------------------------------
    # define the mesh functions and get the points
    # --------------------------------------------------------------------------------

    skinFn = OpenMaya.MFnMesh()
    skinFn.setObject(skinObj)
    targetFn = OpenMaya.MFnMesh()
    targetFn.setObject(targetObj)
    intermediateFn = OpenMaya.MFnMesh()
    intermediateFn.setObject(intermediateObj)

    deformedFn = OpenMaya.MFnMesh()
    deformedFn.setObject(deformedObj)

    skinPoints = skinFn.getPoints()
    targetPoints = targetFn.getPoints()
    intermediatePoints = intermediateFn.getPoints()

    extractPoints = OpenMaya.MPointArray(intermediatePoints)

    """
    # create an intersection list between the delta points and the given vertex list
    vList = []
    if listString != '':
        array = listString.split(',')
        array = map(int, array)
        intersectList = list(set(pointList) & set(array))
        pointList = intersectList
    """

    # --------------------------------------------------------------------------------
    # duplicate the original
    # --------------------------------------------------------------------------------

    resultFn = OpenMaya.MFnMesh()
    resultObj = OpenMaya.MObject()

    # copies the mesh using API functions but its not easily undoable
    # resultObj = resultFn.copy(intermediateObj, OpenMaya.cvar.MObject_kNullObj)
    # duplicating the mesh through maya commands is a bit more complex
    # but the undo comes for free

    resultMesh = cmds.duplicate(shapeList[0], rc=True)

    shapes = cmds.listRelatives(resultMesh, s=True)
    # delete the main shape node and deactivate the intermediate object
    cmds.delete(shapes[0])
    cmds.setAttr(shapes[1] + '.intermediateObject', 0)
    cmds.rename(shapes[1], shapes[0])
    attrList = ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']
    for a in attrList:
        cmds.setAttr(resultMesh[0] + '.' + a, l=False)
    selList.clear()
    selList.add(shapes[0])
    resultObj = selList.getDependNode(0)
    resultFn.setObject(resultObj)

    resultPoints = resultFn.getPoints()
    cmds.delete("Skinned1")

    # --------------------------------------------------------------------------------
    # build a relative coordinate space by first preturbing
    # the origional mesh and then building a coordinate space
    # on the skinned mesh
    # --------------------------------------------------------------------------------

    xArray = OpenMaya.MPointArray(intermediatePoints)
    yArray = OpenMaya.MPointArray(intermediatePoints)
    zArray = OpenMaya.MPointArray(intermediatePoints)

    xPointArray = OpenMaya.MPointArray()
    yPointArray = OpenMaya.MPointArray()
    zPointArray = OpenMaya.MPointArray()

    start_time = time.time()
    vert_itr = OpenMaya.MItMeshVertex(intermediateObj)
    while not vert_itr.isDone():
        i = vert_itr.index()

        xArray[i] = (intermediatePoints[i].x + 1.0, intermediatePoints[i].y, intermediatePoints[i].z)
        yArray[i] = (intermediatePoints[i].x, intermediatePoints[i].y + 1.0, intermediatePoints[i].z)
        zArray[i] = (intermediatePoints[i].x, intermediatePoints[i].y, intermediatePoints[i].z + 1.0)

        vert_itr.next()

    intermediateFn.setPoints(xArray)
    xPointArray = skinFn.getPoints()

    vert_itr = OpenMaya.MItMeshVertex(intermediateObj)
    while not vert_itr.isDone():
        i = vert_itr.index()

        offX = xPointArray[i].x - skinPoints[i].x
        offY = xPointArray[i].y - skinPoints[i].y
        offZ = xPointArray[i].z - skinPoints[i].z
        xPointArray[i] = (offX, offY, offZ)

        vert_itr.next()

    intermediateFn.setPoints(yArray)
    yPointArray = skinFn.getPoints()

    vert_itr = OpenMaya.MItMeshVertex(intermediateObj)
    while not vert_itr.isDone():
        i = vert_itr.index()

        offX = yPointArray[i].x - skinPoints[i].x
        offY = yPointArray[i].y - skinPoints[i].y
        offZ = yPointArray[i].z - skinPoints[i].z
        yPointArray[i] = (offX, offY, offZ)

        vert_itr.next()

    intermediateFn.setPoints(zArray)
    zPointArray = skinFn.getPoints()

    vert_itr = OpenMaya.MItMeshVertex(intermediateObj)
    while not vert_itr.isDone():
        i = vert_itr.index()

        offX = zPointArray[i].x - skinPoints[i].x
        offY = zPointArray[i].y - skinPoints[i].y
        offZ = zPointArray[i].z - skinPoints[i].z
        zPointArray[i] = (offX, offY, offZ)

        vert_itr.next()

    # set the original points back
    intermediateFn.setPoints(intermediatePoints)
    # print("--- %s sec coordinate space ---" % (time.time() - start_time))
    # --------------------------------------------------------------------------------
    # perform the extraction from the skinned mesh
    # --------------------------------------------------------------------------------

    start_time = time.time()
    vert_itr = OpenMaya.MItMeshVertex(intermediateObj)
    while not vert_itr.isDone():
        i = vert_itr.index()
        extractMatrix = OpenMaya.MMatrix(((zPointArray[i].x, zPointArray[i].y, zPointArray[i].z, 0),
                                          (xPointArray[i].x, xPointArray[i].y, xPointArray[i].z, 0),
                                          (yPointArray[i].x, yPointArray[i].y, yPointArray[i].z, 0),
                                          (skinPoints[i].x, skinPoints[i].y, skinPoints[i].z, 1)))
        resultMatrix = OpenMaya.MMatrix(
            ((0, 0, 1, 0), (1, 0, 0, 0), (0, 1, 0, 0), (resultPoints[i].x, resultPoints[i].y, resultPoints[i].z, 1)))

        point = OpenMaya.MPoint()
        point = targetPoints[i] * extractMatrix.inverse()
        point *= resultMatrix
        extractPoints[i] = point

        vert_itr.next()
    # print("--- %s sec vertex extraction ---" % (time.time() - start_time))
    deformedFn.setPoints(extractPoints)

    # --------------------------------------------------------------------------------
    # cleanup
    # --------------------------------------------------------------------------------

    # cmds.sets(resultFn.fullPathName(), e=True, fe='initialShadingGroup')
    # parentNode = cmds.listRelatives(resultFn.fullPathName(), p=True)
    # resultName = cmds.rename(parentNode, sel[1] + '_corrective')

    cmds.select(cl=True)