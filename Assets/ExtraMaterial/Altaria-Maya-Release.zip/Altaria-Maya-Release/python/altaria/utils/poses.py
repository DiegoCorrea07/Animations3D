import json
import os
import importlib

import maya.cmds as cmds

import utils.utils as utils
importlib.reload(utils)

def __get_joint_attributes(jnt_name):
    jnt_item = dict()
    jnt_item['WorldTX'] = (cmds.xform(jnt_name, query=True, translation=True, worldSpace=True))
    jnt_item['LocalTX'] = (cmds.xform(jnt_name, query=True, translation=True, worldSpace=False))

    jnt_item['WorldRX'] = (cmds.xform(jnt_name, query=True, rotation=True, worldSpace=True))
    jnt_item['LocalRX'] = (cmds.xform(jnt_name, query=True, rotation=True, worldSpace=False))

    return jnt_item


def strip_namespace(ctl):
    tokens = ctl.nodeName().split(":")
    if len(tokens) == 1:
        return ctl.nodeName()

    new_name = ":".join(tokens[1:])
    return new_name

def __get_pose_info(selection):
    controls = {}
    errors = []

    for item in selection:
        try:
            jnt_name = utils.strip_namespace(item)
        except RuntimeWarning:
            jnt_name = item

        try:
            node_type = cmds.objectType(item)
        except RuntimeWarning:
            errors.append("Cound not get type for " + item)

        global_matrix = None
        local_matrix = None
        global_tx = None
        global_rx = None
        global_sx = None
        local_tx = None
        local_rx = None
        local_sx = None
        node_type = None
        try:
            # Matrix
            global_matrix = cmds.xform(item, q=True, ws=True, m=True)
            local_matrix = cmds.xform(item, q=True, os=True, m=True)
        except Exception as e:
            errors.append("Could not get Matrix for " + item)
        try:
            # Global
            global_tx = cmds.xform(item, q=True, ws=True, t=True)
            global_rx = cmds.xform(item, q=True, ws=True, ro=True)
            global_sx = cmds.xform(item, q=True, r=True, s=True)
        except Exception as e:
            errors.append("Could not get global values for " + item)
        try:
            # Local
            local_tx = cmds.xform(item, q=True, os=True, t=True)
            local_rx = cmds.xform(item, q=True, os=True, ro=True)
            local_sx = cmds.xform(item, q=True, r=True, s=True)

        except Exception as e:
            errors.append("Could not get local values for " + item)

        controls[str(jnt_name)] = {'globalMatrix': global_matrix,
                                   'localMatrix': local_matrix,
                                   'globalTX': global_tx,
                                   'globalRX': global_rx,
                                   'globalSX': global_sx,
                                   'localTX': local_tx,
                                   'localRX': local_rx,
                                   'localSX': local_sx,
                                   'node_type': node_type}

    if errors:
        errors = list(set(errors))
        print("Pose errors: " + ", ".join(errors))
    return controls


def save_pose(pose_name=None, pose_path=None):
    sel = cmds.ls(sl=True)
    if not sel:
        cmds.select("Reference", hi=True)

    # cmds.select(sel, r=True, hi=True)
    object_list = cmds.ls(sl=True)
    cmds.select(cl=True)

    pose_info = __get_pose_info(object_list)

    file_path = os.path.join(pose_path, pose_name + ".pose")
    with open(os.path.join(file_path), 'w') as outfile:
        json.dump(pose_info, outfile, sort_keys=True, indent=4, ensure_ascii=False)


def apply_pose(pose_path, namespace=None, object_list=None, local_transform=True, global_transform=False, tx=True,
               rx=True, sx=True):
    with open(os.path.normpath(pose_path), "r") as f:
        pose = json.load(f)

    if not object_list:
        object_list = cmds.ls(sl=True)

    # If we don't have any defined selection assume that we want to apply the pose to whatever the pose contains
    if not object_list:
        object_list = list()
        for ctrl in pose:
            object_list.append(ctrl)

    errors = []
    for ctrl in object_list:
        try:
            if "Shape" in ctrl:
                continue
            clean_ctrl_name = None
            if ":" in ctrl:
                clean_ctrl_name = ctrl.split(":")[1]
            else:
                clean_ctrl_name = ctrl
            try:
                if local_transform:
                    if tx and not rx:
                        cmds.xform(ctrl, os=True, t=pose[clean_ctrl_name]['localTX'])
                    elif rx and not tx:
                        cmds.xform(ctrl, os=True, ro=pose[clean_ctrl_name]['localRX'])
                    else:
                        cmds.xform(ctrl, os=True, m=pose[clean_ctrl_name]['localMatrix'])

                elif global_transform:
                    if tx and not rx:
                        cmds.xform(ctrl, ws=True, t=pose[clean_ctrl_name]['globalTX'])
                    elif rx and not tx:
                        cmds.xform(ctrl, ws=True, ro=pose[clean_ctrl_name]['globalRX'])
                    else:
                        cmds.xform(ctrl, ws=True, m=pose[clean_ctrl_name]['globalMatrix'])
            except Exception as e:
                errors.append(ctrl)
        except:
            pass

    if errors:
        errors = list(set(errors))
        print("Could not apply pose to: " + ", ".join(errors))
