import glob
import os
import importlib
import json
from functools import partial
import math
import shutil
import numpy as np

# Maya
import maya.cmds as cmds
import maya.mel as mel
from maya import OpenMayaUI
import maya.api.OpenMaya as OpenMaya
from maya.app.general.mayaMixin import MayaQWidgetDockableMixin

# PySide2
from PySide2 import QtCore, QtWidgets, QtGui
from PySide2.QtUiTools import loadUiType
from shiboken2 import wrapInstance

import utils.utils as utils
importlib.reload(utils)

import utils.poses as poses
importlib.reload(poses)

import widgets.treewidgets as tree_widgets
importlib.reload(tree_widgets)

import utils.vertex_colors as vertex_colors
importlib.reload(vertex_colors)

import dtcore.fbx.fbx_wrapper as fbx_wrapper
import pymel.core as pm

MODULE_PATH = os.path.dirname(os.path.realpath(__file__))
UI_FILE = os.path.join(MODULE_PATH, "ui", "mainUI.ui")
form, base = generated_class, base_class = loadUiType(UI_FILE)
TOOL_NAME = "maya_altaria_cloth_tool_2"
WINDOW_NAME = "Unity - DemoTeam Altaria Cloth"

TARGET_JOINTS = ['Spine', 'Spine1', 'Spine2', 'Spine3', 'Neck', 'Neck1', 'Neck2', 'Neck3', 'Head', 'LeftUpLeg',
                  'LeafLeftUpLegRoll1', 'LeafLeftUpLegRoll2', 'LeftLeg', 'LeftFoot', 'RightUpLeg',
                  'LeafRightUpLegRoll1', 'LeafRightUpLegRoll2', 'RightLeg', 'RightFoot', 'LeftShoulder', 'LeftArm',
                  'LeafLeftArmRoll1', 'LeafLeftArmRoll2', 'LeafLeftArmRoll3', 'LeafLeftArmRoll4', 'LeftForeArm',
                  'LeafLeftForeArmRoll1', 'LeafLeftForeArmRoll2', 'LeafLeftForeArmRoll3', 'LeafLeftForeArmRoll4',
                  'LeftHand', 'RightShoulder', 'RightArm', 'LeafRightArmRoll1', 'LeafRightArmRoll2',
                  'LeafRightArmRoll3', 'LeafRightArmRoll4', 'RightForeArm', 'LeafRightForeArmRoll1',
                  'LeafRightForeArmRoll2', 'LeafRightForeArmRoll3', 'LeafRightForeArmRoll4', 'RightHand']


def get_maya_win():
    win_ptr = OpenMayaUI.MQtUtil.mainWindow()
    return wrapInstance(int(win_ptr), QtWidgets.QMainWindow)


def delete_workspace_control(control):
    if cmds.workspaceControl(control, q=True, exists=True):
        cmds.workspaceControl(control, e=True, close=True)
        cmds.deleteUI(control, control=True)


def create_mixin(window_ui, tool_name, window_name):
    class MixinDock(MayaQWidgetDockableMixin, window_ui):
        TOOL_NAME = tool_name

        def __init__(self, parent=None):
            delete_workspace_control(self.TOOL_NAME + 'WorkspaceControl')
            super(self.__class__, self).__init__(parent=parent)

            self.mayaMainWindow = get_maya_win()
            self.setObjectName(self.__class__.TOOL_NAME)

            self.setWindowFlags(QtCore.Qt.Window)
            self.setWindowTitle(WINDOW_NAME)
            self.resize(200, 200)

            self.setLayout(QtWidgets.QVBoxLayout())

        def run(self):
            self.setObjectName(tool_name)
            workspace_control_name = self.objectName() + "WorkspaceControl"
            self.show(dockable=True, floating=True)
            self.raise_()

    return MixinDock


class MainUI(form, base):
    def __init__(self, parent=None):
        super(MainUI, self).__init__(parent)
        self.setupUi(self)

        # Settings
        settings_path = os.path.join(os.getenv('APPDATA'), "altaria")
        if not os.path.exists(settings_path):
            os.mkdir(settings_path)
        self.settings = QtCore.QSettings(os.path.join(settings_path, "tool_settings.ini"), QtCore.QSettings.IniFormat)
        self.settings.setFallbacksEnabled(False)

        # Tab Bar
        self.active_tab_index = 0
        self.tabWidget.currentChanged.connect(self.tab_changed)

        # Color Patches
        self.patches_color = []
        self.patches_vtx_ids = []
        self.mListColorPatchesBtn.clicked.connect(self.list_vertex_colors)
        self.mVertexColorTreeWidget.itemDoubleClicked.connect(self.select_patch_vertices)

        # Poses
        self.mRefreshPosesBtn.clicked.connect(self.refresh_poses)
        self.mSavePoseBtn.clicked.connect(self.pose_save)
        self.mLoadPoseBtn.clicked.connect(self.pose_apply)
        self.mPosesTreeWidget.itemDoubleClicked.connect(self.pose_apply)
        self.mDeletePoseBtn.clicked.connect(self.pose_delete)
        self.mExportPoseToAlembicBtn.clicked.connect(partial(self.export_pose_to_alembic, self.mExportAlembicAvatarChk.isChecked(), self.mExportFbxAvatarChk.isChecked()))

        # ABC
        #self.mTargetCmb.currentIndexChanged.connect(self.abc_refresh_lists)
        self.mABCRefreshBtn.clicked.connect(self.abc_refresh_lists)
        self.mABCRawTreeWidget.itemDoubleClicked.connect(self.preview_alembic)
        self.mABCConvertedTreeWidget.itemDoubleClicked.connect(self.preview_alembic)
        self.mABCDeltaTreeWidget.itemDoubleClicked.connect(self.preview_alembic)

        self.mExtractDeltaDataBtn.clicked.connect(self.extract_delta_data)

        # Settings
        self.mBrowseAbcRawFolderBtn.clicked.connect(partial(self.browse_path, "mAlembicRawPath"))
        self.mBrowseAbcConvFolderBtn.clicked.connect(partial(self.browse_path, "mAlembicConvertedPath"))
        self.mBrowseAbcDeltaFolderBtn.clicked.connect(partial(self.browse_path, "mAlembicDeltaPath"))

        self.mBrowsePoseFolderBtn.clicked.connect(partial(self.browse_path, "mPosePath"))
        self.mBrowseAlembicAvatarOutputBtn.clicked.connect(partial(self.browse_path, "mAlembicAvatarOutputPath"))
        self.mBrowseFbxAvatarOutputBtn.clicked.connect(partial(self.browse_path, "mFbxAvatarOutputPath"))

        self.mBrowsePoseToAvatarWorkFileBtn.clicked.connect(partial(self.browse_file, "mPoseToAvatarWorkFile"))
        self.mBrowseMayaDeltaWorkFileBtn.clicked.connect(partial(self.browse_file, "mMayaDeltaWorkFile"))

        self.load_settings()

        self.abc_refresh_lists()
        self.refresh_poses()

    def hideEvent(self, *args):
        self.save_settings()

    def load_settings(self):
        # self.splitter.setSizes([160, 400])
        self.resize(self.settings.value(TOOL_NAME+'/size', QtCore.QSize(538, 604)))
        self.move(self.settings.value(TOOL_NAME+'/pos', QtCore.QPoint(500, 500)))
        self.active_tab_index = self.settings.value(TOOL_NAME+'/tabIndex', 0)
        self.tabWidget.setCurrentIndex(int(self.active_tab_index))
        self.mAlembicRawPath.setText(self.settings.value(TOOL_NAME+'/mAlembicRawPath', ""))
        self.mAlembicConvertedPath.setText(self.settings.value(TOOL_NAME+'/mAlembicConvertedPath', ""))
        self.mAlembicDeltaPath.setText(self.settings.value(TOOL_NAME+'/mAlembicDeltaPath', ""))
        self.mPosePath.setText(self.settings.value(TOOL_NAME+'/mPosePath', ""))
        self.mAlembicAvatarOutputPath.setText(self.settings.value(TOOL_NAME+'/mAlembicAvatarOutputPath', ""))
        self.mFbxAvatarOutputPath.setText(self.settings.value(TOOL_NAME+'/mFbxAvatarOutputPath', ""))
        self.mMayaDeltaWorkFile.setText(self.settings.value(TOOL_NAME+'/mMayaDeltaWorkFile', ""))
        self.mPoseToAvatarWorkFile.setText(self.settings.value(TOOL_NAME+'/mPoseToAvatarWorkFile', ""))

    def save_settings(self):
        try:
            self.settings.setValue(TOOL_NAME+'/size', self.size())
            self.settings.setValue(TOOL_NAME+'/pos', self.pos())
            self.settings.setValue(TOOL_NAME+'/tabIndex', self.active_tab_index)
            self.settings.setValue(TOOL_NAME+'/mAlembicRawPath', self.mAlembicRawPath.text())
            self.settings.setValue(TOOL_NAME+'/mAlembicConvertedPath', self.mAlembicConvertedPath.text())
            self.settings.setValue(TOOL_NAME+'/mAlembicDeltaPath', self.mAlembicDeltaPath.text())
            self.settings.setValue(TOOL_NAME+'/mPosePath', self.mPosePath.text())
            self.settings.setValue(TOOL_NAME+'/mAlembicAvatarOutputPath', self.mAlembicAvatarOutputPath.text())
            self.settings.setValue(TOOL_NAME+'/mFbxAvatarOutputPath', self.mFbxAvatarOutputPath.text())
            self.settings.setValue(TOOL_NAME+'/mMayaDeltaWorkFile', self.mMayaDeltaWorkFile.text())
            self.settings.setValue(TOOL_NAME+'/mPoseToAvatarWorkFile', self.mPoseToAvatarWorkFile.text())

        except RuntimeError as e:
            print(e)

    # ---------- Tab -----------------------
    def tab_changed(self, tab_idx):
        self.active_tab_index = tab_idx

        if tab_idx == 1:
            self.refresh_poses()

    # ---------- Utils ---------------------
    def browse_path(self, target):
        folder_path = QtWidgets.QFileDialog.getExistingDirectory()
        folder_path = folder_path.replace("\\", "/")

        if target == "mAlembicRawPath":
            self.mAlembicRawPath.setText(folder_path)
        elif target == "mAlembicConvertedPath":
            self.mAlembicConvertedPath.setText(folder_path)
        elif target == "mAlembicDeltaPath":
            self.mAlembicDeltaPath.setText(folder_path)
        elif target == "mPosePath":
            self.mPosePath.setText(folder_path)
        elif target == "mPoseToAvatarWorkFile":
            self.mPoseToAvatarWorkFile.setText(folder_path)
        elif target == "mAlembicAvatarOutputPath":
            self.mAlembicAvatarOutputPath.setText(folder_path)
        elif target == "mFbxAvatarOutputPath":
            self.mFbxAvatarOutputPath.setText(folder_path)


        self.save_settings()
    def browse_file(self, target):
        file_name, _ = QtWidgets.QFileDialog.getOpenFileName(None, 'Open', "")
        if not file_name:
            return

        file_name = file_name.replace("\\", "/")
        if target == "mMayaDeltaWorkFile":
            self.mMayaDeltaWorkFile.setText(file_name)
        elif target == "mPoseToAvatarWorkFile":
            self.mPoseToAvatarWorkFile.setText(file_name)

        self.save_settings()

    # ---------- POSES -------------

    def refresh_poses(self):
        self.mPosesTreeWidget.clear()
        if self.mPosePath.text() != "":
            pose_files = glob.glob(self.mPosePath.text() + "/*.pose")
            for f in pose_files:
                f = os.path.normpath(f)
                node_name = os.path.basename(f)

                item = QtWidgets.QTreeWidgetItem()
                item.setText(0, node_name)
                item.setText(1, f)
                self.mPosesTreeWidget.addTopLevelItem(item)
        else:
            print("Please specify a pose path in Settings tab")

    def pose_save(self):
        if self.mPosePath.text() == "":
            print("Please specify a pose path in Settings tab")
            return

        cmds.select(cl=True)
        text, ok = QtWidgets.QInputDialog.getText(self, 'Save Pose', 'Enter name:')
        if ok:
            poses.save_pose(pose_path=self.mPosePath.text(), pose_name=text)
            self.refresh_poses()

    def pose_apply(self, item=None):
        if item:
            f = item.text(1)
            poses.apply_pose(f, object_list=TARGET_JOINTS)

    def pose_delete(self, item=None):
        selected_items = self.mPosesTreeWidget.selectedItems()
        if len(selected_items) == 0:
            return

        for pose in selected_items:
            os.remove(pose.text(1))

        self.refresh_poses()

    def export_pose_to_alembic(self, export_alembic=True, export_fbx=True):
        selected_items = self.mPosesTreeWidget.selectedItems()
        if len(selected_items) == 0:
            print("No poses selected")
            return

        pose_lead_frames = 30
        cnt = 0
        for pose in selected_items:
            pose_full_path = pose.text(1)

            # Get filename
            filename = os.path.basename(pose_full_path)
            filename = filename.split(".")[0]

            # Open workfile
            cmds.file(self.mPoseToAvatarWorkFile.text(), o=True, f=True)
            cmds.currentTime(0)

            # Apply neutral pose
            poses.apply_pose(os.path.join(self.mPosePath.text(), "neutral.pose"), object_list=TARGET_JOINTS)
            cmds.select(TARGET_JOINTS, r=True)
            cmds.setKeyframe()

            # Apply extreme pose
            cmds.currentTime(pose_lead_frames)
            poses.apply_pose(pose_full_path, object_list=TARGET_JOINTS)
            cmds.select(TARGET_JOINTS, r=True)
            cmds.setKeyframe()

            # Eular filter
            cmds.select("Reference", hi=True, r=True)
            cmds.filterCurve()


            # If we choose to export a fbx file with mesh and joints
            if export_fbx:
                utils.reset_bake_options()

                cmds.select("Reference", hi=True)
                bake_jnts = cmds.ls(sl=True, type="joint")
                cmds.bakeResults(bake_jnts,
                                 simulation=True,
                                 t=(0, 30),
                                 sampleBy=1,
                                 oversamplingRate=1,
                                 disableImplicitControl=True,
                                 preserveOutsideKeys=True,
                                 sparseAnimCurveBake=False,
                                 removeBakedAttributeFromLayer=False,
                                 removeBakedAnimFromLayer=False,
                                 bakeOnOverrideLayer=False,
                                 minimizeRotation=True,
                                 controlPoints=False,
                                 shape=True)

                # EXPORT FBX
                output_path = os.path.join(self.mFbxAvatarOutputPath.text(), filename + ".fbx")
                cmds.select("sim_mesh", r=True)
                cmds.select("Reference", add=True)
                cmds.select("Boots_GEO", add=True)

                cmds.file(output_path, force=True, options="v=0;", typ="FBX export", pr=True, es=True)

            cmds.currentTime(0)
            cmds.select(cl=True)

            if export_alembic:
                # Meshes to export
                meshes = ["sim_mesh", "Boots_GEO"]
                cmds.select(meshes, r=True)

                roots = ""
                for obj in meshes:
                    roots += " -root " + str(obj)

                start = 0
                end = pose_lead_frames

                output_path = os.path.join(self.mAlembicAvatarOutputPath.text(), filename + ".abc")

                command = "-frameRange " + str(start) + " " + str(
                    end) + " -dataFormat ogawa" + roots + " -file " + output_path
                cmds.AbcExport(j=command)

            print(f"Pose - {filename} - {cnt}/{len(selected_items)}")
            cnt += 1
        print("Export completed!")

    # ---------- VERTEX PATCHES -------------
    def list_vertex_colors(self):
        sel = cmds.ls(sl=True)
        if len(sel) == 0:
            return


        self.mVertexColorTreeWidget.clear()
        self.patches_color, self.patches_vtx_ids = vertex_colors.list_vertex_colors(sel[0])
        for i in range(0, len(self.patches_color)):
            tw = tree_widgets.VertexColorItem(parent=self.mVertexColorTreeWidget,
                                                     name="Patch_"+utils.pad_zeros(i),
                                                     vtx_count=len(self.patches_vtx_ids[i]),
                                                     vtx_color=self.patches_color[i])

            self.mVertexColorTreeWidget.addTopLevelItem(tw)


        self.current_selected_object = sel[0]
        self.mStatusLabel.setText(f"Patch Count: {len(self.patches_color)}")

    def select_patch_vertices(self, item):
        row = self.mVertexColorTreeWidget.indexOfTopLevelItem(item)
        sel_string = []
        for i in range(0, len(self.patches_vtx_ids[row])):
            sel_string.append(f"{self.current_selected_object}.vtx[{self.patches_vtx_ids[row][i]}]")
        cmds.select(sel_string, r=True)


    # ---------- ABC -----------------------
    def abc_refresh_lists(self):

        # RAW
        if self.mAlembicRawPath.text() != "":
            self.mABCRawTreeWidget.clear()
            abc_files = glob.glob(self.mAlembicRawPath.text() + "/*.abc")
            for f in abc_files:
                f = os.path.normpath(f)
                node_name = os.path.basename(f).split(".")[0]

                item = QtWidgets.QTreeWidgetItem()
                item.setText(0, node_name)
                item.setText(1, f)
                self.mABCRawTreeWidget.addTopLevelItem(item)
        else:
            print("Please specify a Raw Alembic path in Settings tab")

        # Converted
        if self.mAlembicConvertedPath.text() != "":
            self.mABCConvertedTreeWidget.clear()
            abc_files = glob.glob(self.mAlembicConvertedPath.text() + "/*.abc")
            for f in abc_files:
                f = os.path.normpath(f)
                node_name = os.path.basename(f).split(".")[0]

                item = QtWidgets.QTreeWidgetItem()
                item.setText(0, node_name)
                item.setText(1, f)
                self.mABCConvertedTreeWidget.addTopLevelItem(item)
        else:
            print("Please specify a Converted Alembic path in Settings tab")

        # Delta
        if self.mAlembicDeltaPath.text() != "":
            self.mABCDeltaTreeWidget.clear()
            abc_files = glob.glob(self.mAlembicDeltaPath.text() + "/*.abc")
            for f in abc_files:
                f = os.path.normpath(f)
                node_name = os.path.basename(f).split(".")[0]

                item = QtWidgets.QTreeWidgetItem()
                item.setText(0, node_name)
                item.setText(1, f)
                self.mABCDeltaTreeWidget.addTopLevelItem(item)
        else:
            print("Please specify a Converted Alembic path in Settings tab")

    def preview_alembic(self, item):
        f = item.text(1)

        f = os.path.normpath(f)
        node_name = os.path.basename(f).split(".")[0]
        print(f"Node name: {node_name}")
        cmds.AbcImport(f, mode="import")

    def extract_delta_data(self):
        import utils.fbx_wrapper as fbx_wrapper

        sel = self.mABCConvertedTreeWidget.selectedItems()
        if sel:
            abc_files = []
            for abc in sel:
                print(abc.text(1))
                abc_files.append(abc.text(1))

        cnt = 0
        for f in abc_files:
            cmds.file(self.mMayaDeltaWorkFile.text(), o=True, f=True)

            if cmds.objExists("high_to_low_rez"):
                cmds.delete("high_to_low_rez")

            f = os.path.normpath(f)
            node_name = os.path.basename(f).split(".")[0]
            print(f"Node name: {node_name}")
            print(f"Exporting - {f} --- {cnt}/{len(abc_files)}")

            name_split = node_name.split("_")
            pose_name = '_'.join(name_split[:2]).lower()
            print(f"Pose name: {pose_name}")

            full_fbx_path = os.path.join(self.mFbxAvatarOutputPath.text(), pose_name + ".fbx")
            if not os.path.exists(full_fbx_path):
                print(f"Could not locate FBX file - {full_fbx_path}")
                continue
            full_fbx_path = full_fbx_path.replace("\\", "/")

            cmds.AbcImport(f, mode="import")
            cmds.setAttr(f"{node_name}_AlembicNode.speed", 3)

            # IMPORT MOCAP CLIP
            fbx_wrapper.FBXImportConstraints(v=0)
            fbx_wrapper.FBXImportCameras(v=0)
            fbx_wrapper.FBXImportFillTimeline(v=1)
            fbx_wrapper.FBXImportMode(v="exmerge")
            fbx_wrapper.FBXImportSkins(v=0)
            fbx_wrapper.FBXImportConstraints(v=0)
            mel.eval(f"FBXImport -f \"{full_fbx_path}\" -t -1;")

            cmds.currentTime(0)

            print("Export Alembic")

            # Meshes
            meshes = ["output"]
            cmds.select(meshes, r=True)

            roots = ""
            for obj in meshes:
                roots += " -root " + str(obj)

            start = 0
            end = 30

            output_path = os.path.join(self.mAlembicDeltaPath.text(), pose_name + ".abc")

            command = f'-frameRange {start} {end} -dataFormat ogawa {roots} -pythonPerFrameCallback "import utils.extractDeltasAPI as extractDeltasAPI;importlib.reload(extractDeltasAPI);extractDeltasAPI.extractDeltas(\\"Skinned\\", \\"high_to_low_rez\\")" -file {output_path}'
            """
            command = "-frameRange " + str(start) + " " + str(
                end) + " -dataFormat ogawa" + roots + " -pythonPerFrameCallback \"import utils.extractDeltasAPI as extractDeltasAPI;importlib.reload(extractDeltasAPI);extractDeltasAPI.extractDeltas(\\\"Skinned\\\", \\\"high_to_low_rez\\\")\" -file " + output_path
            """
            cmds.AbcExport(j=command)

            print(f"Exported {output_path}")



def show_ui():
    tool_mixin = create_mixin(MainUI, TOOL_NAME, WINDOW_NAME)
    tool_mixin().run()