from PySide2 import QtCore, QtWidgets, QtGui

# ------------------------------------------------------------------------------
# Custom QTreeWidgetItem
# ------------------------------------------------------------------------------
class VertexColorItem(QtWidgets.QTreeWidgetItem):
    '''
    Custom QTreeWidgetItem with Widgets
    '''

    def __init__(self, parent, name, vtx_count, vtx_color):
        '''
        parent (QTreeWidget) : Item's QTreeWidget parent.
        name   (str)         : Item's name. just an example.
        '''

        ## Init super class ( QtGui.QTreeWidgetItem )
        super(VertexColorItem, self).__init__(parent)

        ## Column 0 - Text:
        self.setText(0, name)

        ## Column 1 - Vtx Count:
        vtx_count_label = QtWidgets.QLabel(str(vtx_count))
        self.treeWidget().setItemWidget(self, 1, vtx_count_label)

        ## Column 2 - Color
        myLabel = QtWidgets.QLabel()
        myLabel.setAutoFillBackground(True)  # This is important!!
        # color = QtGui.QColor(233, 10, 150)
        alpha = 255

        values = "{r}, {g}, {b}, {a}".format(r=int(vtx_color[0]*255),
                                             g=int(vtx_color[1]*255),
                                             b=int(vtx_color[2]*255),
                                             a=alpha
                                             )
        myLabel.setText(values)
        myLabel.setStyleSheet("QLabel { background-color: rgba(" + values + "); }")
        self.treeWidget().setItemWidget(self, 2, myLabel)
        """
        ## Column 1 - SpinBox:
        self.spinBox = QtWidgets.QSpinBox()
        self.spinBox.setValue(0)
        self.treeWidget().setItemWidget(self, 1, self.spinBox)

        ## Column 2 - Button:
        self.button = QtWidgets.QPushButton()
        self.button.setText("button %s" % name)
        
        self.treeWidget().setItemWidget(self, 2, self.button)
        """

        ## Signals
        # self.treeWidget().connect(self.button, QtCore.SIGNAL("clicked()"), self.buttonPressed)

    @property
    def name(self):
        '''
        Return name ( 1st column text )
        '''
        return self.text(0)

    @property
    def value(self):
        '''
        Return value ( 2nd column int)
        '''
        return self.spinBox.value()

    def buttonPressed(self):
        '''
        Triggered when Item's button pressed.
        an example of using the Item's own values.
        '''
        pass
        #print(f"This Item name:{self.name} value:{self.value}")